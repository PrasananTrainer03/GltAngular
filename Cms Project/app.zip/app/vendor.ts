export class Vendor {
   
    public venId : number;
    public venName : string; 
    public venPassword : string; 
    public venEmail : string; 
    public venMobile : string; 
    public venDob : string;
    public venAddress : string;
    constructor( )
{ }
}

