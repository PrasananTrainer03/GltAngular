import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cmsmain',
  templateUrl: './cmsmain.component.html',
  styleUrls: ['./cmsmain.component.css']
})
export class CMSMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
