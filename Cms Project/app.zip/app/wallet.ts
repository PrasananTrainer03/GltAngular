export class Wallet {
    public walId : number;
    public walAmount : number;
    public cusId : number;
    public walType : string;
    constructor(  ){}
}
