export class Orders {
   
    public ordId : number;
    public ordTime : string;
    public ordAmount : string;
    public ordLocation : string;
    public ordStatus : string;
    public qtyOrder : number;
    public cusId : number;
    public foodId : number;
    public venId : number;
    public walType : string;
    public ordComments : string;
    constructor( )
{ }
}
