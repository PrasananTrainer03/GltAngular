﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog2
{
    class Program
    {
        static void Main(string[] args)
        {
            string name;
            Console.WriteLine("Enter Your Name   ");
            name = Console.ReadLine();
            Console.WriteLine("Name is  " +name);
        }
    }
}
