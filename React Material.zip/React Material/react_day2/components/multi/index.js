import multi from "./multi"
export default multi;
