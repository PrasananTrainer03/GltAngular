import formnew from "./formnew"
export default formnew;
