import validateform from "./validateform"
export default validateform;
