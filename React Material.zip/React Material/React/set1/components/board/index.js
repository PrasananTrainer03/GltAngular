import board from "./board"
export default board;
