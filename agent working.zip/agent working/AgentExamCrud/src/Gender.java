
public enum Gender {

	MALE,FEMALE
}
